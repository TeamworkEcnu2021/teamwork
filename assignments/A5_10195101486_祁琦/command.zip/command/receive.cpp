#include "Receive.h"
#include <iostream>
using namespace std;

void Receiver::DishA()
{
    cout << "One roast beef." << endl;
}

void Receiver::DishB()
{
    cout << "One Ceasar Salad." << endl;
}
