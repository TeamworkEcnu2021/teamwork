#ifndef COMMAND_H_INCLUDED
#define COMMAND_H_INCLUDED
#include "Receive.h"

class Command
{
public:
    Command(Receiver* p)
    {
        pReceiver = p;
    };
    virtual ~Command(){};
    virtual void execute() = 0;
protected:
    Receiver* pReceiver;
};


#endif // COMMAND_H_INCLUDED
