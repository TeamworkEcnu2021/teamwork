#include "Invoker.h"
#include <iostream>
using namespace std;

/*Invoker::Invoker(Command *pCommand)
{
    mpCommand = pCommand;
}*/

Invoker::~Invoker()
{
    for(vector<Command*>::iterator iter = cVec.begin();
        iter != cVec.end();iter++)
    {
        delete(*iter);
    }
    cVec.clear();
}

void Invoker::call(Command *p)
{
    cVec.push_back(p);
}

void Invoker::submitCmd()
{
    for(vector<Command*>::iterator iter = cVec.begin();
        iter != cVec.end();iter++)
    {
        (*iter)->execute();
    }
}
