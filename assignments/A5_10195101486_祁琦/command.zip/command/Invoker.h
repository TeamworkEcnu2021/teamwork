#ifndef INVOKER_H_INCLUDED
#define INVOKER_H_INCLUDED

#include "command.h"
#include <vector>

using namespace std;

class Invoker
{
public:
    //Invoker(Command* pCommand);
    virtual ~Invoker();
    void call(Command *p);
    void submitCmd();
protected:
    vector<Command*> cVec;
};

#endif // INVOKER_H_INCLUDED
