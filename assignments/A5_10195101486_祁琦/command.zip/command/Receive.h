#ifndef RECEIVE_H_INCLUDED
#define RECEIVE_H_INCLUDED

class Receiver
{
public:
    void DishA();
    void DishB();
};


#endif // RECEIVE_H_INCLUDED
