#ifndef CONCRETE_H_INCLUDED
#define CONCRETE_H_INCLUDED

#include "command.h"
#include "receive.cpp"

class CommandDishA : public Command
{
public:
    CommandDishA(Receiver *p):Command(p){};
    void execute()
    {
        pReceiver->DishA();
    }
};

class CommandDishB : public Command
{
public:
    CommandDishB(Receiver *p):Command(p){};
    void execute()
    {
        pReceiver->DishB();
    }
};

#endif // CONCRETE_H_INCLUDED
