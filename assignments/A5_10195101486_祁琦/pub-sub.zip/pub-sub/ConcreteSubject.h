#ifndef CONCRETESUBJECT_H_INCLUDED
#define CONCRETESUBJECT_H_INCLUDED

#include <string>
#include "Observer.h"
#include "Subject.h"

using namespace std;

class ConcreteSubject : public Subject
{
public:
    ConcreteSubject(string name) : sName(name){};
    ~ConcreteSubject(){};

    void setStatus(string status);
    string getStatus();
protected:
    string sName;
    //string mStatus;
};

#endif // CONCRETESUBJECT_H_INCLUDED
