#include <iostream>
#include "ConcreteSubject.h"

using namespace std;

void ConcreteSubject::setStatus(string status)
{
    sName = status;
}

string ConcreteSubject::getStatus()
{
    return sName;
}
