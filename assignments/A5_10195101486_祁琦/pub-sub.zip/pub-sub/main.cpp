#include <iostream>
#include "Subject.cpp"
#include "Observer.h"
#include "ConcreteSubject.cpp"
#include "ConcreteObserver.cpp"

using namespace std;

int main()
{
    Subject *course = new ConcreteSubject("CSAPP");

    Observer *student1 = new ConcreteObserver("John", course);
    Observer *student2 = new ConcreteObserver("Hugh", course);

    course->addObserver(student1);
    course->addObserver(student2);
    course->notifyObserver();

    course->setStatus("Operting system");
    course->notifyObserver();

    return 0;
}
