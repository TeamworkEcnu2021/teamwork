#ifndef CONCRETEOBSERVER_H_INCLUDED
#define CONCRETEOBSERVER_H_INCLUDED


#include <string>
#include "Observer.h"
#include "Subject.h"

using namespace std;

class ConcreteObserver : public Observer
{
public:
    ConcreteObserver(string name, Subject *subject): name(name), subject(subject){};
    ~ConcreteObserver(){}
    void Update();

protected:
    string name;
    Subject *subject;
};


#endif // CONCRETEOBSERVER_H_INCLUDED
