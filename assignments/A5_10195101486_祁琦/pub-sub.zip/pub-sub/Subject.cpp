#include "Subject.h"
#include <iostream>

using namespace std;

void Subject::addObserver(Observer *observer)
{
    observerList.push_back(observer);
}

void Subject::removeObserver(Observer *observer)
{
    for(vector<Observer*>::iterator iter = observerList.begin();
        iter!=observerList.end();iter++)
    {
        if(*iter == observer)
        {
            observerList.erase(iter);
            return;
        }
    }
}

void Subject::notifyObserver()
{
    for(vector<Observer*>::iterator iter = observerList.begin();
        iter != observerList.end();iter++)
    {
        (*iter)->Update();
    }
}
