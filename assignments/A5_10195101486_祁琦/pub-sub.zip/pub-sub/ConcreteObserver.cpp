#include <iostream>
#include "ConcreteObserver.h"
using namespace std;

void ConcreteObserver::Update()
{
    cout << "Hi " << name << "! New course posting:"<< subject->getStatus() << endl;
    return;
}
