#ifndef OBSERVER_H_INCLUDED
#define OBSERVER_H_INCLUDED

class Observer
{
public:
    Observer(){};
    virtual ~Observer(){};
    virtual void Update() = 0;
};

#endif // OBSERVER_H_INCLUDED
