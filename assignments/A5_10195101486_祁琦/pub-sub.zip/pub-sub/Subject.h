#ifndef SUBJECT_H_INCLUDED
#define SUBJECT_H_INCLUDED


#include <vector>
#include "Observer.h"

using namespace std;

class Subject
{
public:
    Subject(){};
    virtual ~Subject(){};
    void addObserver(Observer *observer);
    void removeObserver(Observer * observer);
    void notifyObserver();
    virtual string getStatus() = 0;
    virtual void setStatus(string status) = 0;
protected:
    vector<Observer*> observerList;
};


#endif // SUBJECT_H_INCLUDED
