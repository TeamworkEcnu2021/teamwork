#include "state.h"


int Trip::GetDays()
{
    return tdays;
}

void Trip::SetDays(int days)
{
    tdays = days;
}

void Trip::GetState()
{
    tState->CurrentState(this);
}

void Trip::SetState(State *state)
{
    tState = state;
}
