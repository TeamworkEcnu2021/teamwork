#include "Trip.cpp"
#include "state.cpp"
#include <iostream>

using namespace std;

int main()
{
    Trip *t = new Trip(new ProphaseState());
    for(int i = 1;i<40;i+=5)
    {
        t->SetDays(i);
        t->GetState();
    }
    delete t;
    return 0;
}
