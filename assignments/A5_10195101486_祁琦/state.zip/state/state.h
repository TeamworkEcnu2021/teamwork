#ifndef STATE_H_INCLUDED
#define STATE_H_INCLUDED

class Trip;
class State
{
public:
    virtual void CurrentState(Trip *pTrip){}
    virtual void Prophase(){}
    virtual void Metaphase(){}
    virtual void Anaphase(){}
    virtual void End(){}
};

class Trip
{
public:
    Trip(State *state):tState(state),tdays(0){}
    ~Trip(){}
    int GetDays();
    void SetDays(int days);
    void SetState(State *state);
    void GetState();
protected:
    State *tState;
    int tdays;
};

#endif // STATE_H_INCLUDED
