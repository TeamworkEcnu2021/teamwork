#include "state.h"
#include <iostream>
using namespace std;

class EndState: public State
{
public:
    void End(Trip *t)
    {
        cout << "Endding the trip and go home." << endl;
    }
    void CurrentState(Trip *t)
    {
        End(t);
    }
};

class AnaphaseState : public State
{
public:
    void Anaphase(Trip *t)
    {
        if(t->GetDays()<30)
            cout << "Day " << t->GetDays() <<", in Barcelona." << endl;
        else
        {
            t->SetState(new EndState());
            t->GetState();
        }
    }
    void CurrentState(Trip *t)
    {
        Anaphase(t);
    }
};

class MetaphaseState : public State
{
public:
    void Metaphase(Trip *t)
    {
        if(t->GetDays()<20)
            cout << "Day " << t->GetDays() <<", in Madrid." << endl;
        else
        {
            t->SetState(new AnaphaseState());
            t->GetState();
        }
    }
    void CurrentState(Trip *t)
    {
        Metaphase(t);
    }
};

class ProphaseState : public State
{
public:
    void Prophase(Trip *t)
    {
        if(t->GetDays()<10)
            cout << "Day " << t->GetDays() <<", in Seville." << endl;
        else
        {
            t->SetState(new MetaphaseState());
            t->GetState();
        }
    }
    void CurrentState(Trip *t)
    {
        Prophase(t);
    }
};
