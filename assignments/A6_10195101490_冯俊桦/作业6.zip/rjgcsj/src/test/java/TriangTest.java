import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Assert;
public class TriangTest {
    @Test
    public void test()
    {
        assertEquals(1,trityp.Triang(2,3,4));
        assertEquals(2,trityp.Triang(2,2,3));
        assertEquals(3,trityp.Triang(2,2,2));
        assertEquals(4,trityp.Triang(1,2,3));
    }
    @Test
    public void testOne()
    {
        assertEquals(1,TritypMutantOne.Triang(2,3,4));
        assertEquals(2,TritypMutantOne.Triang(2,2,3));
        assertEquals(3,TritypMutantOne.Triang(2,2,2));
        assertEquals(4,TritypMutantOne.Triang(1,2,3));
    }
    @Test
    public void testTwo()
    {
        assertEquals(1,TritypMutantTwo.Triang(2,3,4));
        assertEquals(2,TritypMutantTwo.Triang(2,2,3));
        assertEquals(3,TritypMutantTwo.Triang(2,2,2));
        assertEquals(4,TritypMutantTwo.Triang(1,2,3));
    }
}
