import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class TrityMutanOneTest {

    TrityMutanOne tri = new TrityMutanOne();
    @After
    public void tearDown()
    {
        tri = null;
        tri = new TrityMutanOne();
    }
    @Test
    public void triangTest1() {
        assertEquals(4,tri.Triang(0,0,0));
        assertEquals(2,tri.Triang(3,3,4));
        assertEquals(2,tri.Triang(4,6,4));
        assertEquals(4,tri.Triang(4,9,4));
        assertEquals(2,tri.Triang(6,5,5));
        assertEquals(4,tri.Triang(12,5,5));
        assertEquals(4,tri.Triang(1,2,3));
        assertEquals(1,tri.Triang(3,4,5));
        assertEquals(3,tri.Triang(3,3,3));
        assertEquals(4,tri.Triang(2,1,3));
        assertEquals(4,tri.Triang(3,2,1));
    }
}