import org.junit.*;

import java.util.Random;

import static org.junit.Assert.assertEquals;

public class TritypMutantOneTest {
    TritypMutantOne tri=new TritypMutantOne();

    //    Triang = 1 if triangle is scalene
    //    Triang = 2 if triangle is isosceles
    //    Triang = 3 if triangle is equilaterala
    //    Triang = 4 if not a triangle

    @Test
    public void testTriang_4(){
        assertEquals(1,tri.Triang(3,2,4));
        assertEquals(1,tri.Triang(5,6,7));
        assertEquals(2,tri.Triang(4,4,7));
        assertEquals(2,tri.Triang(8,8,7));
        assertEquals(3,tri.Triang(5,5,5));
        assertEquals(3,tri.Triang(7,7,7));
        assertEquals(4,tri.Triang(2,3,7));
        assertEquals(4,tri.Triang(3,4,7));
    }

}